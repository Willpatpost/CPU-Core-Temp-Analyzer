# CS 417 Semester Project

This is my final submission for the Semester Project - CPU Temps after correcting previous mistakes.

William Poston
7/21/24
UIN: 01261639